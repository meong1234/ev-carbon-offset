import Hero from "@/components/home/Hero"

export default function Home() {
  return (
    <main>
      <Hero />
      {/* Other components can be added here */}
    </main>
  )
}

