"use client"

import { useState, useEffect } from "react"

export default function MouseMoveEffect() {
  const [mouseX, setMouseX] = useState(0)
  const [mouseY, setMouseY] = useState(0)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMouseX(e.clientX)
      setMouseY(e.clientY)
    }

    window.addEventListener("mousemove", handleMouseMove)

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  return (
    <div
      style={{
        position: "absolute",
        top: mouseY,
        left: mouseX,
        transform: `translate(-50%, -50%)`,
        pointerEvents: "none",
      }}
    >
      {/* Add your visual effect here */}
    </div>
  )
}

