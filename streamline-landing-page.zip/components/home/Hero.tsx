import type React from "react"
import { Button } from "@/components/ui/button"

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Dynamic background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#001219] via-[#005F73] to-[#0A9396] animate-gradient-x"></div>

      {/* Particle effect */}
      <div className="absolute inset-0">
        <div className="relative w-full h-full">
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              className="absolute bg-white rounded-full opacity-20 animate-float"
              style={{
                width: Math.random() * 5 + 1 + "px",
                height: Math.random() * 5 + 1 + "px",
                left: Math.random() * 100 + "%",
                top: Math.random() * 100 + "%",
                animationDuration: Math.random() * 3 + 2 + "s",
                animationDelay: Math.random() * 2 + "s",
              }}
            ></div>
          ))}
        </div>
      </div>

      <div className="container mx-auto px-4 text-center relative z-10">
        <h1
          className="font-inter font-extrabold text-white mb-6 leading-tight animate-fade-in-up"
          style={{
            fontSize: "clamp(2.5rem, 5vw, 4.5rem)",
            textShadow:
              "0 0 20px rgba(0, 224, 199, 0.5), 0 0 40px rgba(0, 224, 199, 0.3), 0 0 60px rgba(0, 224, 199, 0.1)",
          }}
        >
          Driving Change with Every Ride
        </h1>
        <p
          className="font-inter font-semibold text-[#40E0D0] mb-8 leading-relaxed animate-fade-in-up animation-delay-300"
          style={{
            fontSize: "clamp(1.25rem, 2.5vw, 2rem)",
            textShadow: "0 0 10px rgba(64, 224, 208, 0.5)",
          }}
        >
          Your Carbon Credits Help Gig Riders Switch to EVs, Reducing Urban Air Pollution
        </p>
        <p
          className="font-openSans text-white mb-12 max-w-3xl mx-auto animate-fade-in-up animation-delay-600"
          style={{
            fontSize: "clamp(1rem, 1.5vw, 1.25rem)",
            lineHeight: "1.8",
          }}
        >
          Join the movement to transform urban transportation. Every credit you purchase directly supports gig economy
          workers in their transition to electric vehicles, creating cleaner cities and a brighter future.
        </p>
        <div className="flex flex-col sm:flex-row justify-center items-center gap-6 animate-fade-in-up animation-delay-900">
          <Button
            size="lg"
            className="w-full sm:w-auto text-lg font-bold uppercase bg-gradient-to-r from-[#00E0C7] to-[#00AFFF] text-white hover:from-[#00E0C7]/90 hover:to-[#00AFFF]/90 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg hover:shadow-[#00E0C7]/20 rounded-full px-8 py-4"
          >
            Buy Carbon Credits
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="w-full sm:w-auto text-lg font-bold uppercase border-2 border-[#00E0C7] text-[#00E0C7] hover:bg-[#00E0C7]/10 transition-all duration-300 hover:shadow-lg hover:shadow-[#00E0C7]/20 rounded-full px-8 py-4"
          >
            Learn More
          </Button>
        </div>
      </div>
    </section>
  )
}

export default Hero

