"use client"

import type React from "react"
import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-[rgba(1,22,30,0.95)] backdrop-blur-md" : "bg-transparent"
      } border-b border-[rgba(64,224,208,0.1)]`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Logo />
          <div className="hidden md:block">
            <NavLinks isScrolled={isScrolled} />
          </div>
          <div className="hidden md:block">
            <Button
              size="sm"
              className="bg-gradient-to-r from-[#00E0C7] to-[#00AFFF] text-white font-bold uppercase text-sm px-6 py-3 rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 ease-in-out"
            >
              Buy Credits
            </Button>
          </div>
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-[#00E0C7] hover:text-white hover:bg-[rgba(0,224,199,0.1)] focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#00E0C7]"
            >
              <span className="sr-only">Open main menu</span>
              {isMenuOpen ? (
                <X className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="block h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`md:hidden ${isMenuOpen ? "block" : "hidden"}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-[rgba(1,22,30,0.95)] backdrop-blur-md">
          <NavLinks isScrolled={true} mobile />
          <div className="mt-4">
            <Button
              size="sm"
              className="w-full bg-gradient-to-r from-[#00E0C7] to-[#00AFFF] text-white font-bold uppercase text-sm px-6 py-3 rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 ease-in-out"
            >
              Buy Credits
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}

const Logo: React.FC = () => (
  <Link href="/" className="flex items-center">
    <div className="text-2xl font-bold font-montserrat">
      <span className="bg-gradient-to-r from-[#00E0C7] to-[#00AFFF] text-transparent bg-clip-text font-black animate-glow">
        EV
      </span>
      <span className="text-white font-bold">Carbon</span>
      <span className="text-[#40E0D0] italic text-base font-medium animate-pulse">&</span>
      <span className="bg-gradient-to-r from-[#40E0D0] to-[#00ffcc] text-transparent bg-clip-text font-bold animate-underline">
        Offset
      </span>
    </div>
  </Link>
)

interface NavLinksProps {
  isScrolled: boolean
  mobile?: boolean
}

const NavLinks: React.FC<NavLinksProps> = ({ isScrolled, mobile }) => {
  const linkClass = `px-3 py-2 rounded-md text-sm font-semibold uppercase tracking-wider transition-all duration-300 
    text-white hover:text-[#00ffcc]
    hover:bg-[rgba(0,224,208,0.1)] relative overflow-hidden group`

  const activeLinkClass = `${linkClass} text-[#00ffcc]`

  return (
    <div className={mobile ? "space-y-2" : "flex space-x-4"}>
      <Link href="#home" className={activeLinkClass}>
        Home
        <span className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#00E0C7] to-[#00AFFF] transform scale-x-0 transition-transform duration-300 group-hover:scale-x-100"></span>
      </Link>
      <Link href="#how-it-works" className={linkClass}>
        How It Works
        <span className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#00E0C7] to-[#00AFFF] transform scale-x-0 transition-transform duration-300 group-hover:scale-x-100"></span>
      </Link>
      <Link href="#impact-dashboard" className={linkClass}>
        Impact Dashboard
        <span className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#00E0C7] to-[#00AFFF] transform scale-x-0 transition-transform duration-300 group-hover:scale-x-100"></span>
      </Link>
      <Link href="#for-businesses" className={linkClass}>
        For Businesses
        <span className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#00E0C7] to-[#00AFFF] transform scale-x-0 transition-transform duration-300 group-hover:scale-x-100"></span>
      </Link>
      <Link href="#about" className={linkClass}>
        About
        <span className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-[#00E0C7] to-[#00AFFF] transform scale-x-0 transition-transform duration-300 group-hover:scale-x-100"></span>
      </Link>
    </div>
  )
}

export default Navbar

